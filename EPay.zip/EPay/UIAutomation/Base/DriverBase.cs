﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace UIAutomation.Base
{
    public class DriverBase
    {
        public IWebDriver Driver = null;
        
        public void LaunchBrowser(string browserName)
        {
            switch (browserName)
            {
                case "Chrome":                    
                    ChromeOptions options = new ChromeOptions();
                    options.AddArgument("--enable-popup-blocking");
                    Driver = new ChromeDriver(options);
                    break;
                default:
                    break;
            }
        }               
    }
}
