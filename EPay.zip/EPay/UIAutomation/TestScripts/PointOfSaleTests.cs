using PointOfSaleTerminal.Models;
using UIAutomation.Base;

namespace UIAutomation.TestScripts
{
    [TestClass]
    public class PointOfSaleTests : DriverBase
    {
        [TestMethod]
        public void Test1()
        {
            PointOfSaleTerminal.Service.PointOfSaleTerminal terminal = TestPreRequisite();

            #region Test 1.Scan these items in this order: ABCDABA,  Verify that the total price is $13.25
            // 1.Scan these items in this order: ABCDABA
            // Verify that the total price is $13.25
            terminal.ScanProduct("A");
            terminal.ScanProduct("B");
            terminal.ScanProduct("C");
            terminal.ScanProduct("D");
            terminal.ScanProduct("A");
            terminal.ScanProduct("B");
            terminal.ScanProduct("A");

            // Calcu
            decimal result = terminal.CalculateTotal();
            double expectedResult = 13.25;

            // Print the total price
            Assert.IsTrue(Convert.ToDouble(result).Equals(expectedResult));
            #endregion            
        }        

        [TestMethod]
        public void Test2()
        {
            PointOfSaleTerminal.Service.PointOfSaleTerminal terminal = TestPreRequisite();

            #region Test 2.Scan these items in this order: CCCCCC,  Verify that the total price is $6
            // 2.Scan these items in this order: CCCCCC
            // Verify that the total price is $6
            terminal.ScanProduct("C");
            terminal.ScanProduct("C");
            terminal.ScanProduct("C");
            terminal.ScanProduct("C");
            terminal.ScanProduct("C");
            terminal.ScanProduct("C");
            terminal.ScanProduct("C");

            // Calculate total
            decimal result = terminal.CalculateTotal();
            double expectedResult = 6;

            // Print the total price
            Assert.IsTrue(Convert.ToDouble(result).Equals(expectedResult));
            #endregion            
        }

        [TestMethod]
        public void Test3()
        {            
            PointOfSaleTerminal.Service.PointOfSaleTerminal terminal = TestPreRequisite();

            #region Test 2.Scan these items in this order: ABCD,  Verify that the total price is $7.25
            // 2.Scan these items in this order: ABCD
            // Verify that the total price is $7.25
            terminal.ScanProduct("A");
            terminal.ScanProduct("B");
            terminal.ScanProduct("C");
            terminal.ScanProduct("D");            

            // Calculate total
            decimal result = terminal.CalculateTotal();
            double expectedResult = 7.25;

            // Print the total price
            Assert.IsTrue(Convert.ToDouble(result).Equals(expectedResult));
            #endregion            
        }
                
        private static PointOfSaleTerminal.Service.PointOfSaleTerminal TestPreRequisite()
        {
            // Create a new PointOfSaleTerminal instance
            var terminal = new PointOfSaleTerminal.Service.PointOfSaleTerminal();

            // Set the pricing data
            terminal.SetPricing(new[]
            {
            new ProductPricing("A", 1.25m, new VolumePrice(3, 3.00m)),
            new ProductPricing("B", 4.25m),
            new ProductPricing("C", 1.00m, new VolumePrice(6, 5.00m)),
            new ProductPricing("D", 0.75m)
        });
            return terminal;
        }        
    }
}