using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using UIAutomation.Base;

namespace UIAutomation.TestScripts
{
    [TestClass]
    public class SignInAndSendMoneyTest : DriverBase
    {
        [TestMethod]
        public void SignInAndRegisterWithEmailAndPassword()
        {
            LaunchBrowser("Chrome");
            Driver.Url = "https://www.xe.com/send-money/";

            IWebElement SignInAndSendBtn = Driver.FindElement(By.CssSelector("a[name*='Primary']"));
            Actions actions = new Actions(Driver);
            actions.MoveToElement(SignInAndSendBtn);
            actions.Perform();

            SignInAndSendBtn.Click();

            IWebElement AlertAcceptBtn = Driver.FindElement(By.XPath("//button[contains(text(),'Accept')]"));
            AlertAcceptBtn.Click();

            IWebElement EmailTxt = Driver.FindElement(By.Id("email"));
            IWebElement PasswordTxt = Driver.FindElement(By.Id("password"));

             string Email = "abc@gmail.com";
             string Password = "Test@1234";

            EmailTxt.SendKeys(Email);
            PasswordTxt.SendKeys(Password);

            IWebElement RegisterNowBtn = Driver.FindElement(By.XPath("//button[@type='submit']"));
            Assert.IsTrue(RegisterNowBtn.Enabled);
        }    
    }
}