using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using UIAutomation.Base;

namespace UIAutomation.TestScripts
{
    [TestClass]
    public class CurrencyConverterTest : DriverBase
    {
        [TestMethod]
        public void ValidateErrorMessage()
        {
            string invalidInput = "a";
            string expectedErrorMessage = "Please enter a valid amount";

            //Handle Alert
            IWebElement AlertAcceptBtn = Driver.FindElement(By.XPath("//button[contains(text(),'Accept')]"));
            AlertAcceptBtn.Click();
            IWebElement AmountTxt = Driver.FindElement(By.CssSelector("div[class*='amount']"));            

            //Amount Textbox click and clear, send invalid input
            string javascript = "arguments[0].click()";
            IJavaScriptExecutor jsExecutor = (IJavaScriptExecutor)Driver;
            jsExecutor.ExecuteScript(javascript, AmountTxt);
            AmountTxt.Clear();
            AmountTxt.SendKeys(invalidInput);

            //Validate error mrssage
            IWebElement ErrorMsg = Driver.FindElement(By.CssSelector("div[class*='currency-converter__ErrorText']"));
            Assert.IsTrue(ErrorMsg.Displayed);
            Assert.Equals(ErrorMsg.Text, expectedErrorMessage);
        }

        [TestMethod]
        public void VerifyDropdownValue()
        {            
            IWebElement DropdownArrow = Driver.FindElement(By.Id("#midmarketFromCurrency-descriptiveText"));
            DropdownArrow.Click();

            var INRValue  = Driver.FindElements(By.XPath("//span[contains(text(),'Indian Rupee')]"));
            Assert.IsTrue(INRValue.Count==1);            
        }

        [TestMethod]
        public void VerifyButtonFeaturesConvert()
        {
            IWebElement ConvertBtn = Driver.FindElement(By.CssSelector("div[class*='miscellany__TooltipContainer']+button"));
            Assert.Equals(ConvertBtn.Text, "Convert");
        }

        [TestInitialize()]

        public void BeforeTest()
        {
            LaunchBrowser("Chrome");
            Driver.Url = "https://www.xe.com/currencyconverter/";
            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
        }

        [TestCleanup()]
        public void TestCleanUp()
        {
            Driver.Quit();
            Driver.Dispose();
        }
    }
}