﻿using PointOfSaleTerminal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointOfSaleTerminal.Service
{
    public class PointOfSaleTerminal
    {
        private List<ProductPricing> _pricingData;
        private Dictionary<string, int> _scannedProducts;

        public PointOfSaleTerminal()
        {
            _pricingData = new List<ProductPricing>();
            _scannedProducts = new Dictionary<string, int>();
        }

        public void SetPricing(IEnumerable<ProductPricing> pricingData)
        {
            _pricingData = pricingData.ToList();
        }

        public void ScanProduct(string productCode)
        {
            if (!_pricingData.Any(p => p.ProductCode == productCode))
            {
                throw new ArgumentException($"Product {productCode} not found in pricing data.");
            }

            if (!_scannedProducts.ContainsKey(productCode))
            {
                _scannedProducts[productCode] = 1;
            }
            else
            {
                _scannedProducts[productCode]++;
            }
        }

        public decimal CalculateTotal()
        {
            decimal total = 0;

            foreach (var pricing in _pricingData)
            {
                if (_scannedProducts.ContainsKey(pricing.ProductCode))
                {
                    var quantity = _scannedProducts[pricing.ProductCode];
                    var volumePrice = pricing.VolumePrice;
                    if (volumePrice != null && quantity >= volumePrice.VolumeQuantity)
                    {
                        // 7 .. 3 -> 5
                        // 2
                        var discountedQuantity = quantity / volumePrice.VolumeQuantity;
                        var nonDiscountedQuantity = (quantity % volumePrice.VolumeQuantity);


                        total += discountedQuantity * volumePrice.PriceOfVolume + nonDiscountedQuantity * pricing.UnitPrice;
                    }
                    else
                    {
                        total += quantity * pricing.UnitPrice;
                    }
                }
            }

            return total;
        }
    }

}
