﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointOfSaleTerminal.Models
{
    public class VolumePrice 
    {
        public int VolumeQuantity { get; set; }
        public decimal PriceOfVolume { get; set; }

        public VolumePrice(int quantity, decimal price)
        {
            VolumeQuantity = quantity;
            PriceOfVolume = price;
        }
    }
}
