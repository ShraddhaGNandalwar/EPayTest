﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointOfSaleTerminal.Models
{
    public class ProductPricing 
    {
        public string ProductCode { get; set; }
        public decimal UnitPrice { get; set; }
        public VolumePrice VolumePrice { get; set; }


        public ProductPricing(string productCode, decimal unitPrice, VolumePrice volumePrice = null)
        {
            ProductCode = productCode;
            UnitPrice = unitPrice;
            VolumePrice = volumePrice;
        }
    }
}
